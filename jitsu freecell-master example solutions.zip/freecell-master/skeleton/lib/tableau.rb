require_relative 'card'

class Tableau

  def initialize(cards = [])
    @cards = cards
    @grabbed = nil
  end

  def add_cards(cards)
    # p cards
    if self.empty? || cards == @grabbed || last.stackable?(cards[0])
      @cards += cards
    else
      raise UserError, "card(s) cannot be stacked on this tableau"
    end
  end

  def empty?
    @cards.empty?
  end

  def last
    @cards.last
  end

  def [](index)
    @cards[index]
  end

  def grabbable?(index)
    (index...@cards.length-1).all? { |i| @cards[i+1].stackable?(@cards[i]) }
  end


  def grab(index)
    raise UserError.new("cannot grab that card") unless grabbable?(index)

    @grabbed = @cards[index..-1]
    @cards = @cards[0...index]
    @grabbed
  end

  def count
    @cards.count
  end

  private

end

