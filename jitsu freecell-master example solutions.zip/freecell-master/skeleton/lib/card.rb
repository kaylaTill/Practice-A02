require 'colorize'
require_relative 'errors'

class Card

  # check the protected methods and assets!

  def self.suits
    [:spade, :diamond, :club, :heart]
  end

  def self.values
    [
      :ace,
      :two,
      :three,
      :four,
      :five,
      :six,
      :seven,
      :eight,
      :nine,
      :ten,
      :jack,
      :queen,
      :king
    ]
  end

  def self.all_cards
    deck = []
    Card.values.each do |value|
      Card.suits.each do |suit|
        deck << Card.new(value, suit)
      end
    end
    deck
  end

  attr_reader :value, :suit

  def initialize(value, suit)
    @value = value
    @suit = suit
  end

  def to_s
    value_str = NUM_VALUES[@value].to_s
    value_str = "A" if value_str == "1"
    value_str = "J" if value_str == "11"
    value_str = "Q" if value_str == "12"
    value_str = "K" if value_str == "13"
    value_str + SUIT_STRINGS[@suit]
  end

  def num
    NUM_VALUES[@value]
  end

  def stackable?(card)
    raise UserError, "card is a king" if @value == :king

    # use the Card::color method down below!
    opposite_color?(card) && correct_order?(card)
  end

  def opposite_color?(other_card)
    color != other_card.color
  end

  def correct_order?(other_card)
    num == other_card.num - 1
  end

  def display(bg_color = :white)
    to_s.rjust(3).colorize(:background => bg_color, :color => color)
  end

  protected

  def color
    case suit
    when :spade, :club
      :black
    when :heart, :diamond
      :red
    end
  end

  NUM_VALUES = {
    :ace => 1,
    :two => 2,
    :three => 3,
    :four => 4,
    :five => 5,
    :six => 6,
    :seven => 7,
    :eight => 8,
    :nine => 9,
    :ten => 10,
    :jack => 11,
    :queen => 12,
    :king => 13
  }

  SUIT_STRINGS = {
    :spade => "♠",
    :heart => "♥",
    :club => "♣",
    :diamond => "♦"
  }

end

